/* =====================================================
   PAGATUPARTE — app.js
   Divide gastos entre amigos. Sin registro. Gratis.
   ===================================================== */

'use strict';

// =====================================================
// CONSTANTS
// =====================================================
const STORAGE_KEY = 'pagatuparte_v1';
const COOKIES_ACCEPTED_KEY = 'pagatuparte_cookies';

const PARTICIPANT_COLORS = [
  '#8B5CF6', '#EC4899', '#10B981', '#F59E0B',
  '#3B82F6', '#EF4444', '#06B6D4', '#84CC16',
  '#F97316', '#A855F7'
];

const CURRENCY_SYMBOLS = {
  EUR: '€', USD: '$', MXN: '$', COP: '$',
  ARS: '$', GBP: '£', BRL: 'R$', CLP: '$', PEN: 'S/'
};

const CATEGORIES = [
  { id: 'food',      emoji: '🍕', label: 'Comida' },
  { id: 'hotel',     emoji: '🏨', label: 'Hotel' },
  { id: 'transport', emoji: '🚗', label: 'Transporte' },
  { id: 'fun',       emoji: '🎉', label: 'Ocio' },
  { id: 'drinks',    emoji: '🍺', label: 'Bebidas' },
  { id: 'shopping',  emoji: '🛒', label: 'Compras' },
  { id: 'tickets',   emoji: '🎟️', label: 'Entradas' },
  { id: 'gas',       emoji: '⛽', label: 'Gasolina' },
  { id: 'health',    emoji: '💊', label: 'Salud' },
  { id: 'other',     emoji: '📦', label: 'Otros' },
];

// =====================================================
// STATE
// =====================================================
let state = {
  trips: [],
  currentTripId: null,
  activeTab: 'participants',
  selectedColor: PARTICIPANT_COLORS[0],
  selectedCategory: 'other',
  splitMode: 'all',
  chart: null,
};

// =====================================================
// UTILITIES
// =====================================================
function uid() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function formatAmount(amount, currency) {
  const symbol = CURRENCY_SYMBOLS[currency] || '€';
  const formatted = parseFloat(amount).toFixed(2);
  if (currency === 'EUR') return `${formatted}${symbol}`;
  if (currency === 'GBP') return `${symbol}${formatted}`;
  if (currency === 'BRL') return `${symbol}${formatted}`;
  if (currency === 'PEN') return `S/ ${formatted}`;
  return `${symbol}${formatted}`;
}

function getInitials(name) {
  return name.trim().split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
}

// =====================================================
// LOCALSTORAGE — con manejo robusto de errores
// =====================================================
function loadState() {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (data) {
      const parsed = JSON.parse(data);
      if (parsed && Array.isArray(parsed.trips)) {
        state.trips = parsed.trips;
      }
    }
  } catch (e) {
    // localStorage no disponible (modo incógnito, cuota llena, etc.)
    console.warn('[PagaTuParte] No se pudo cargar desde localStorage:', e.message);
    state.trips = [];
  }
}

function saveState() {
  try {
    const payload = JSON.stringify({ trips: state.trips });
    localStorage.setItem(STORAGE_KEY, payload);
    return true;
  } catch (e) {
    // Cuota excedida o localStorage bloqueado
    if (e.name === 'QuotaExceededError' || e.code === 22) {
      showToast('⚠️ Almacenamiento lleno. Elimina viajes antiguos.');
    } else {
      console.warn('[PagaTuParte] No se pudo guardar en localStorage:', e.message);
      showToast('⚠️ No se pudieron guardar los cambios en este dispositivo.');
    }
    return false;
  }
}

function clearAllData() {
  if (!confirm('⚠️ ¿Seguro que quieres eliminar TODOS los viajes guardados?\n\nEsta acción no se puede deshacer.')) return;

  // Primero limpiamos el estado en memoria para que la interfaz se actualice
  // incluso si el navegador bloquea localStorage.
  state.trips = [];
  state.currentTripId = null;

  let storageCleared = true;
  try {
    localStorage.removeItem(STORAGE_KEY);
    // No borramos el consentimiento de cookies: no es un viaje ni un dato
    // de la aplicación y así el banner no reaparece al limpiar los viajes.
    storageCleared = localStorage.getItem(STORAGE_KEY) === null;
  } catch (e) {
    storageCleared = false;
    console.warn('[PagaTuParte] Error al limpiar localStorage:', e.message);
  }

  // Si había un gráfico abierto, lo destruimos antes de volver a inicio.
  if (state.chart) {
    try { state.chart.destroy(); } catch (e) { /* noop */ }
    state.chart = null;
  }

  const tripScreen = document.getElementById('trip-screen');
  const homeScreen = document.getElementById('home-screen');
  if (tripScreen) tripScreen.classList.remove('active');
  if (homeScreen) homeScreen.classList.add('active');

  renderHome();
  history.replaceState(null, null, ' ');

  showToast(storageCleared
    ? '🗑️ Todos los viajes y datos guardados han sido eliminados'
    : '⚠️ Se han borrado los datos de esta sesión, pero el navegador no permitió limpiar el almacenamiento');
}

// =====================================================
// GETTERS
// =====================================================
function getCurrentTrip() {
  return state.trips.find(t => t.id === state.currentTripId) || null;
}

function getParticipant(trip, id) {
  return trip.participants.find(p => p.id === id) || null;
}

function getCategoryEmoji(id) {
  const cat = CATEGORIES.find(c => c.id === id);
  return cat ? cat.emoji : '📦';
}

// =====================================================
// DEBT CALCULATION ALGORITHM
// =====================================================
function calculateBalances(trip) {
  const balances = {};
  trip.participants.forEach(p => { balances[p.id] = 0; });

  trip.expenses.forEach(exp => {
    if (!exp.splitAmong || exp.splitAmong.length === 0) return;
    const share = exp.amount / exp.splitAmong.length;
    if (balances[exp.paidBy] !== undefined) balances[exp.paidBy] += exp.amount;
    exp.splitAmong.forEach(pid => {
      if (balances[pid] !== undefined) balances[pid] -= share;
    });
  });

  return balances;
}

function simplifyDebts(trip) {
  const balances = calculateBalances(trip);
  const debts = [];

  const creditors = [];
  const debtors = [];

  Object.entries(balances).forEach(([pid, bal]) => {
    const rounded = Math.round(bal * 100) / 100;
    if (rounded > 0.01) creditors.push({ id: pid, amount: rounded });
    else if (rounded < -0.01) debtors.push({ id: pid, amount: -rounded });
  });

  creditors.sort((a, b) => b.amount - a.amount);
  debtors.sort((a, b) => b.amount - a.amount);

  let i = 0, j = 0;
  while (i < creditors.length && j < debtors.length) {
    const credit = creditors[i];
    const debt = debtors[j];
    const amount = Math.min(credit.amount, debt.amount);

    debts.push({
      from: debt.id,
      to: credit.id,
      amount: Math.round(amount * 100) / 100,
    });

    credit.amount = Math.round((credit.amount - amount) * 100) / 100;
    debt.amount = Math.round((debt.amount - amount) * 100) / 100;

    if (credit.amount < 0.01) i++;
    if (debt.amount < 0.01) j++;
  }

  return debts;
}

function getTotalAmount(trip) {
  return trip.expenses.reduce((sum, e) => sum + e.amount, 0);
}

function getSpendingPerPerson(trip) {
  const spending = {};
  trip.participants.forEach(p => { spending[p.id] = 0; });
  trip.expenses.forEach(exp => {
    if (spending[exp.paidBy] !== undefined) spending[exp.paidBy] += exp.amount;
  });
  return spending;
}

// =====================================================
// WHATSAPP & SHARE
// =====================================================
function generateWhatsAppMessage(trip) {
  const debts = simplifyDebts(trip);
  if (debts.length === 0) return '¡Todos están al día! 🎉';

  const lines = [
    `💸 *PagaTuParte — ${trip.name}*`,
    ``,
    `Resumen de pagos pendientes:`,
    ``,
  ];

  debts.forEach(debt => {
    const from = getParticipant(trip, debt.from);
    const to = getParticipant(trip, debt.to);
    if (from && to) {
      lines.push(`• ${from.name} → ${to.name}: *${formatAmount(debt.amount, trip.currency)}*`);
    }
  });

  lines.push(``);
  lines.push(`Total del viaje: ${formatAmount(getTotalAmount(trip), trip.currency)}`);
  lines.push(`_Calculado con PagaTuParte · pagatuparte.netlify.app_`);

  return lines.join('\n');
}

function generateShareUrl(trip) {
  try {
    const encoded = btoa(unescape(encodeURIComponent(JSON.stringify(trip))));
    return `${window.location.origin}${window.location.pathname}#trip=${encoded}`;
  } catch (e) {
    return window.location.href;
  }
}

function loadTripFromUrl() {
  const hash = window.location.hash;
  if (!hash.startsWith('#trip=')) return null;
  try {
    const encoded = hash.replace('#trip=', '');
    const trip = JSON.parse(decodeURIComponent(escape(atob(encoded))));
    return trip;
  } catch (e) {
    return null;
  }
}

// =====================================================
// EXPORT AS IMAGE — Canvas API (sin dependencias)
// =====================================================
function drawRoundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function exportAsImage() {
  const trip = getCurrentTrip();
  if (!trip) return;

  const debts = simplifyDebts(trip);
  const total = getTotalAmount(trip);
  const currency = trip.currency;

  const W = 640;
  const DEBT_H = 68;
  const headerH = 80;
  const totalSectionH = 100;
  const labelH = 30;
  const footerH = 44;
  const debtCount = Math.max(debts.length, 1);
  const H = headerH + totalSectionH + labelH + debtCount * DEBT_H + 20 + footerH;

  const canvas = document.createElement('canvas');
  const scale = 2; // retina
  canvas.width = W * scale;
  canvas.height = H * scale;
  const ctx = canvas.getContext('2d');
  ctx.scale(scale, scale);

  // --- Background ---
  const bgGrad = ctx.createLinearGradient(0, 0, W, H);
  bgGrad.addColorStop(0, '#0f0f23');
  bgGrad.addColorStop(1, '#1a1035');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, W, H);

  // --- Header bar ---
  const hGrad = ctx.createLinearGradient(0, 0, W, 0);
  hGrad.addColorStop(0, 'rgba(139,92,246,0.25)');
  hGrad.addColorStop(1, 'rgba(99,102,241,0.08)');
  ctx.fillStyle = hGrad;
  ctx.fillRect(0, 0, W, headerH);

  // Header bottom border
  ctx.strokeStyle = 'rgba(139,92,246,0.3)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(0, headerH);
  ctx.lineTo(W, headerH);
  ctx.stroke();

  // Logo
  ctx.font = 'bold 18px Inter, Arial, sans-serif';
  ctx.fillStyle = '#A78BFA';
  ctx.textAlign = 'left';
  ctx.fillText('💸 PagaTuParte', 24, 47);

  // Trip name (right)
  ctx.font = '14px Inter, Arial, sans-serif';
  ctx.fillStyle = '#94A3B8';
  ctx.textAlign = 'right';
  ctx.fillText(trip.name, W - 24, 47);

  // --- Total section ---
  let y = headerH + 22;
  ctx.font = '11px Inter, Arial, sans-serif';
  ctx.fillStyle = '#64748B';
  ctx.textAlign = 'left';
  ctx.fillText('TOTAL DEL VIAJE', 24, y);
  y += 26;

  ctx.font = 'bold 34px Inter, Arial, sans-serif';
  ctx.fillStyle = '#F1F5F9';
  ctx.fillText(formatAmount(total, currency), 24, y);
  y += 22;

  ctx.font = '13px Inter, Arial, sans-serif';
  ctx.fillStyle = '#64748B';
  const participants = trip.participants.length;
  ctx.fillText(`${formatAmount(total / Math.max(participants, 1), currency)} por persona · ${trip.expenses.length} gastos`, 24, y);
  y += 20;

  // Separator
  ctx.strokeStyle = 'rgba(255,255,255,0.06)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(16, y);
  ctx.lineTo(W - 16, y);
  ctx.stroke();
  y += 16;

  // --- Debts label ---
  ctx.font = 'bold 10px Inter, Arial, sans-serif';
  ctx.fillStyle = '#64748B';
  ctx.textAlign = 'left';
  ctx.fillText('QUIÉN DEBE A QUIÉN', 24, y + 2);
  y += labelH;

  // --- Debt rows ---
  if (debts.length === 0) {
    // All settled
    ctx.fillStyle = 'rgba(16,185,129,0.08)';
    drawRoundRect(ctx, 16, y, W - 32, 54, 12);
    ctx.fill();
    ctx.strokeStyle = 'rgba(16,185,129,0.2)';
    ctx.lineWidth = 1;
    ctx.stroke();

    ctx.font = 'bold 15px Inter, Arial, sans-serif';
    ctx.fillStyle = '#10B981';
    ctx.textAlign = 'center';
    ctx.fillText('🎉 ¡Todo está equilibrado! No hay deudas pendientes.', W / 2, y + 30);
    ctx.textAlign = 'left';
    y += DEBT_H;
  } else {
    debts.forEach((debt, idx) => {
      const from = getParticipant(trip, debt.from);
      const to = getParticipant(trip, debt.to);
      if (!from || !to) return;

      // Alternating rows
      ctx.fillStyle = idx % 2 === 0 ? 'rgba(255,255,255,0.035)' : 'rgba(255,255,255,0.018)';
      drawRoundRect(ctx, 16, y, W - 32, DEBT_H - 8, 12);
      ctx.fill();

      const circleY = y + (DEBT_H - 8) / 2;
      const RADIUS = 16;

      // FROM avatar
      ctx.fillStyle = from.color;
      ctx.beginPath();
      ctx.arc(52, circleY, RADIUS, 0, Math.PI * 2);
      ctx.fill();
      ctx.font = 'bold 11px Inter, Arial, sans-serif';
      ctx.fillStyle = 'white';
      ctx.textAlign = 'center';
      ctx.fillText(getInitials(from.name), 52, circleY + 4);

      // FROM name
      ctx.font = 'bold 14px Inter, Arial, sans-serif';
      ctx.fillStyle = '#E2E8F0';
      ctx.textAlign = 'left';
      ctx.fillText(from.name, 76, circleY - 5);
      ctx.font = '12px Inter, Arial, sans-serif';
      ctx.fillStyle = '#64748B';
      ctx.fillText('debe a', 76, circleY + 11);

      // Arrow
      ctx.font = '18px Arial, sans-serif';
      ctx.fillStyle = '#4C4C7A';
      ctx.textAlign = 'center';
      ctx.fillText('→', W / 2, circleY + 6);

      // TO avatar
      ctx.fillStyle = to.color;
      ctx.beginPath();
      ctx.arc(W - 52, circleY, RADIUS, 0, Math.PI * 2);
      ctx.fill();
      ctx.font = 'bold 11px Inter, Arial, sans-serif';
      ctx.fillStyle = 'white';
      ctx.textAlign = 'center';
      ctx.fillText(getInitials(to.name), W - 52, circleY + 4);

      // TO name
      ctx.font = 'bold 14px Inter, Arial, sans-serif';
      ctx.fillStyle = '#E2E8F0';
      ctx.textAlign = 'right';
      ctx.fillText(to.name, W - 76, circleY - 5);

      // Amount
      ctx.font = 'bold 17px Inter, Arial, sans-serif';
      ctx.fillStyle = '#EF4444';
      ctx.textAlign = 'right';
      ctx.fillText(formatAmount(debt.amount, currency), W - 76, circleY + 12);

      y += DEBT_H;
    });
  }

  y += 8;

  // --- Footer ---
  ctx.fillStyle = 'rgba(0,0,0,0.35)';
  ctx.fillRect(0, H - footerH, W, footerH);

  ctx.font = '11px Inter, Arial, sans-serif';
  ctx.fillStyle = '#475569';
  ctx.textAlign = 'center';
  ctx.fillText('pagatuparte.netlify.app · Sin registro · Gratis para siempre', W / 2, H - footerH / 2 + 4);

  // --- Download ---
  try {
    const link = document.createElement('a');
    const safeName = trip.name.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 30);
    link.download = `pagatuparte-${safeName}.png`;
    link.href = canvas.toDataURL('image/png');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('✅ Imagen guardada correctamente');
  } catch (e) {
    showToast('❌ Error al guardar imagen');
    console.error('[PagaTuParte] exportAsImage error:', e);
  }
}

// =====================================================
// TOAST
// =====================================================
let toastTimer = null;
function showToast(message, duration = 2800) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), duration);
}

// =====================================================
// MODAL MANAGEMENT
// =====================================================
function openModal(id) {
  const modal = document.getElementById(id);
  if (!modal) return;
  modal.classList.add('open');
  setTimeout(() => {
    const input = modal.querySelector('input:not([readonly]), select');
    if (input) input.focus();
  }, 320);
}

function closeModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.classList.remove('open');
}

// =====================================================
// TAB MANAGEMENT
// =====================================================
function switchTab(tabName) {
  state.activeTab = tabName;

  document.querySelectorAll('.tab-btn').forEach(btn => {
    const isActive = btn.dataset.tab === tabName;
    btn.classList.toggle('active', isActive);
    btn.setAttribute('aria-selected', isActive ? 'true' : 'false');
  });

  document.querySelectorAll('.tab-panel').forEach(panel => {
    panel.classList.toggle('active', panel.id === `tab-${tabName}`);
  });

  // Move indicator
  const activeBtn = document.querySelector(`.tab-btn[data-tab="${tabName}"]`);
  const indicator = document.getElementById('tab-indicator');
  if (activeBtn && indicator) {
    const bar = document.querySelector('.tab-bar');
    const barRect = bar.getBoundingClientRect();
    const btnRect = activeBtn.getBoundingClientRect();
    indicator.style.left = `${btnRect.left - barRect.left}px`;
    indicator.style.width = `${btnRect.width}px`;
  }

  const trip = getCurrentTrip();
  if (!trip) return;
  if (tabName === 'participants') renderParticipants(trip);
  if (tabName === 'expenses') renderExpenses(trip);
  if (tabName === 'summary') renderSummary(trip);
  if (tabName === 'stats') renderStats(trip);
}

// =====================================================
// RENDER: HOME
// =====================================================
function renderHome() {
  const grid = document.getElementById('trips-grid');
  const empty = document.getElementById('empty-home');
  if (!grid || !empty) return;

  grid.innerHTML = '';

  if (state.trips.length === 0) {
    empty.style.display = '';
    grid.style.display = 'none';
    return;
  }

  empty.style.display = 'none';
  grid.style.display = '';

  state.trips.forEach((trip, index) => {
    const total = getTotalAmount(trip);
    const card = document.createElement('div');
    card.className = 'trip-card';
    card.style.animationDelay = `${index * 0.05}s`;

    const emoji = trip.emoji || '✈️';
    const dateStr = new Date(trip.createdAt).toLocaleDateString('es-ES', {
      day: 'numeric', month: 'short', year: 'numeric'
    });

    card.innerHTML = `
      <span class="trip-card-emoji">${emoji}</span>
      <div class="trip-card-name">${escapeHtml(trip.name)}</div>
      <div class="trip-card-meta">
        <span>👥 ${trip.participants.length} personas</span>
        <span>💰 ${formatAmount(total, trip.currency)}</span>
      </div>
      <div class="trip-card-meta" style="margin-top:4px">
        <span>📅 ${dateStr}</span>
        <span>🧾 ${trip.expenses.length} gastos</span>
      </div>
      <div class="trip-card-actions">
        <button class="trip-card-open" data-trip-id="${trip.id}" aria-label="Abrir viaje ${escapeHtml(trip.name)}">Abrir viaje →</button>
        <button class="trip-card-delete" data-trip-id="${trip.id}" aria-label="Eliminar viaje ${escapeHtml(trip.name)}" title="Eliminar viaje">🗑️</button>
      </div>
    `;
    grid.appendChild(card);
  });
}

// =====================================================
// RENDER: OPEN TRIP
// =====================================================
function openTrip(tripId) {
  state.currentTripId = tripId;
  const trip = getCurrentTrip();
  if (!trip) return;

  document.getElementById('trip-name-display').textContent = trip.name;
  document.getElementById('home-screen').classList.remove('active');
  document.getElementById('trip-screen').classList.add('active');

  const symbol = CURRENCY_SYMBOLS[trip.currency] || '€';
  const amountLabel = document.getElementById('expense-amount-label');
  if (amountLabel) amountLabel.textContent = `Importe (${symbol})`;

  state.activeTab = 'participants';
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === 'participants');
    btn.setAttribute('aria-selected', btn.dataset.tab === 'participants' ? 'true' : 'false');
  });
  document.querySelectorAll('.tab-panel').forEach(p => {
    p.classList.toggle('active', p.id === 'tab-participants');
  });

  renderParticipants(trip);
  updateTripMeta(trip);
  requestAnimationFrame(() => initTabIndicator());
}

function updateTripMeta(trip) {
  const el = document.getElementById('trip-meta-display');
  if (el) el.textContent = `${trip.participants.length} personas · ${trip.expenses.length} gastos`;
}

// =====================================================
// RENDER: PARTICIPANTS
// =====================================================
function renderParticipants(trip) {
  const list = document.getElementById('participants-list');
  const empty = document.getElementById('empty-participants');
  if (!list || !empty) return;

  const balances = calculateBalances(trip);
  list.innerHTML = '';

  if (trip.participants.length === 0) {
    empty.style.display = '';
    list.style.display = 'none';
    return;
  }

  empty.style.display = 'none';
  list.style.display = '';

  trip.participants.forEach((p, i) => {
    const balance = balances[p.id] || 0;
    const balClass = balance > 0.01 ? 'balance-positive' : balance < -0.01 ? 'balance-negative' : 'balance-zero';
    const balText = balance > 0.01
      ? `+${formatAmount(balance, trip.currency)}`
      : balance < -0.01
      ? formatAmount(balance, trip.currency)
      : 'En paz ✓';

    const item = document.createElement('div');
    item.className = 'participant-item';
    item.style.animationDelay = `${i * 0.04}s`;
    item.innerHTML = `
      <div class="avatar" style="background:${p.color}" aria-hidden="true">${getInitials(p.name)}</div>
      <span class="participant-name">${escapeHtml(p.name)}</span>
      <span class="participant-balance ${balClass}">${balText}</span>
      <button class="btn-remove" data-participant-id="${p.id}" aria-label="Eliminar ${escapeHtml(p.name)}">✕</button>
    `;
    list.appendChild(item);
  });
}

// =====================================================
// RENDER: EXPENSES
// =====================================================
function renderExpenses(trip) {
  const list = document.getElementById('expenses-list');
  const empty = document.getElementById('empty-expenses');
  const totalDisplay = document.getElementById('total-display');
  if (!list || !empty) return;

  const total = getTotalAmount(trip);
  if (totalDisplay) totalDisplay.textContent = `Total: ${formatAmount(total, trip.currency)}`;

  list.innerHTML = '';

  if (trip.expenses.length === 0) {
    empty.style.display = '';
    list.style.display = 'none';
    return;
  }

  empty.style.display = 'none';
  list.style.display = '';

  [...trip.expenses].reverse().forEach((exp, i) => {
    const payer = getParticipant(trip, exp.paidBy);
    if (!payer) return;

    const perPerson = exp.splitAmong && exp.splitAmong.length > 0
      ? exp.amount / exp.splitAmong.length : exp.amount;

    const splitAvatars = (exp.splitAmong || []).map(pid => {
      const p = getParticipant(trip, pid);
      if (!p) return '';
      return `<div class="mini-avatar" style="background:${p.color}" title="${escapeHtml(p.name)}">${getInitials(p.name)}</div>`;
    }).join('');

    const dateStr = new Date(exp.date).toLocaleDateString('es-ES', {
      day: 'numeric', month: 'short'
    });

    const item = document.createElement('div');
    item.className = 'expense-item';
    item.style.animationDelay = `${i * 0.04}s`;
    item.innerHTML = `
      <div class="expense-category-icon" aria-hidden="true">${getCategoryEmoji(exp.category)}</div>
      <div class="expense-info">
        <div class="expense-desc">${escapeHtml(exp.description)}</div>
        <div class="expense-detail">Pagó: <strong style="color:${payer.color}">${escapeHtml(payer.name)}</strong> · ${dateStr}</div>
        <div class="expense-split-avatars" aria-label="Dividido entre ${exp.splitAmong ? exp.splitAmong.length : 0} personas">${splitAvatars}</div>
      </div>
      <div class="expense-right">
        <span class="expense-amount">${formatAmount(exp.amount, trip.currency)}</span>
        <span class="expense-per-person">${formatAmount(perPerson, trip.currency)}/persona</span>
        <button class="btn-delete-expense" data-expense-id="${exp.id}" aria-label="Eliminar gasto ${escapeHtml(exp.description)}" title="Eliminar">🗑️</button>
      </div>
    `;
    list.appendChild(item);
  });
}

// =====================================================
// RENDER: SUMMARY
// =====================================================
function renderSummary(trip) {
  const total = getTotalAmount(trip);
  const debts = simplifyDebts(trip);
  const balances = calculateBalances(trip);

  const summaryHero = document.getElementById('summary-hero');
  const summaryContent = document.getElementById('summary-content');
  const emptySummary = document.getElementById('empty-summary');

  if (trip.expenses.length === 0) {
    if (summaryHero) summaryHero.style.display = 'none';
    if (summaryContent) summaryContent.style.display = 'none';
    if (emptySummary) emptySummary.style.display = '';
    return;
  }

  if (emptySummary) emptySummary.style.display = 'none';
  if (summaryHero) summaryHero.style.display = '';
  if (summaryContent) summaryContent.style.display = '';

  const totalEl = document.getElementById('summary-total-amount');
  const avgEl = document.getElementById('summary-avg-amount');
  const countEl = document.getElementById('summary-expenses-count');

  if (totalEl) totalEl.textContent = formatAmount(total, trip.currency);
  const perPerson = trip.participants.length > 0 ? total / trip.participants.length : 0;
  if (avgEl) avgEl.textContent = formatAmount(perPerson, trip.currency);
  if (countEl) countEl.textContent = trip.expenses.length;

  // Balances
  const balancesList = document.getElementById('balances-list');
  if (balancesList) {
    balancesList.innerHTML = '';
    trip.participants.forEach((p, i) => {
      const bal = Math.round((balances[p.id] || 0) * 100) / 100;
      const balClass = bal > 0.01 ? 'balance-positive' : bal < -0.01 ? 'balance-negative' : 'balance-zero';
      const balText = bal > 0.01
        ? `Le deben ${formatAmount(bal, trip.currency)}`
        : bal < -0.01
        ? `Debe ${formatAmount(Math.abs(bal), trip.currency)}`
        : 'En paz ✓';

      const item = document.createElement('div');
      item.className = 'balance-item';
      item.style.animationDelay = `${i * 0.05}s`;
      item.innerHTML = `
        <div class="avatar" style="background:${p.color};width:36px;height:36px;font-size:13px" aria-hidden="true">${getInitials(p.name)}</div>
        <span class="balance-name">${escapeHtml(p.name)}</span>
        <span class="balance-amount ${balClass}">${balText}</span>
      `;
      balancesList.appendChild(item);
    });
  }

  // Debts
  const debtsList = document.getElementById('debts-list');
  if (debtsList) {
    debtsList.innerHTML = '';
    if (debts.length === 0) {
      debtsList.innerHTML = `
        <div class="empty-state" style="padding:24px">
          <div class="empty-emoji">🎉</div>
          <p>¡Todo está equilibrado!</p>
          <span>No hay deudas pendientes</span>
        </div>
      `;
    } else {
      debts.forEach((debt, i) => {
        const from = getParticipant(trip, debt.from);
        const to = getParticipant(trip, debt.to);
        if (!from || !to) return;

        const waMsg = encodeURIComponent(
          `Hola ${to.name}! 💸 Te debo ${formatAmount(debt.amount, trip.currency)} del "${trip.name}". Calculado con PagaTuParte.`
        );
        const waUrl = `https://wa.me/?text=${waMsg}`;

        const item = document.createElement('div');
        item.className = 'debt-item';
        item.style.animationDelay = `${i * 0.06}s`;
        item.innerHTML = `
          <div class="debt-row">
            <div class="debt-from">
              <div class="avatar" style="background:${from.color};width:28px;height:28px;font-size:10px" aria-hidden="true">${getInitials(from.name)}</div>
              ${escapeHtml(from.name)}
            </div>
            <span class="debt-arrow" aria-hidden="true">→</span>
            <div class="debt-to">
              <div class="avatar" style="background:${to.color};width:28px;height:28px;font-size:10px" aria-hidden="true">${getInitials(to.name)}</div>
              ${escapeHtml(to.name)}
            </div>
            <span class="debt-amount">${formatAmount(debt.amount, trip.currency)}</span>
          </div>
          <a href="${waUrl}" target="_blank" rel="noopener noreferrer" class="debt-whatsapp-btn" aria-label="Avisar por WhatsApp a ${escapeHtml(to.name)}">
            💬 Avisar por WhatsApp a ${escapeHtml(to.name)}
          </a>
        `;
        debtsList.appendChild(item);
      });
    }
  }
}

// =====================================================
// RENDER: STATS
// =====================================================
function renderStats(trip) {
  const total = getTotalAmount(trip);
  const isEmpty = trip.expenses.length === 0;
  const emptyEl = document.getElementById('empty-stats');
  const topCard = document.getElementById('top-spender-card');

  const statTotal = document.getElementById('stat-total');
  const statPerPerson = document.getElementById('stat-per-person');
  const statCount = document.getElementById('stat-num-expenses');

  if (statTotal) statTotal.textContent = formatAmount(total, trip.currency);
  if (statPerPerson) statPerPerson.textContent = trip.participants.length > 0
    ? formatAmount(total / trip.participants.length, trip.currency)
    : formatAmount(0, trip.currency);
  if (statCount) statCount.textContent = trip.expenses.length;

  if (emptyEl) emptyEl.style.display = isEmpty ? '' : 'none';
  if (topCard) topCard.style.display = 'none';

  if (isEmpty) {
    if (state.chart) { state.chart.destroy(); state.chart = null; }
    return;
  }

  // Top spender
  const spending = getSpendingPerPerson(trip);
  let topId = null, topAmt = 0;
  Object.entries(spending).forEach(([pid, amt]) => {
    if (amt > topAmt) { topAmt = amt; topId = pid; }
  });
  if (topId && topAmt > 0 && topCard) {
    const topP = getParticipant(trip, topId);
    if (topP) {
      topCard.style.display = '';
      topCard.innerHTML = `
        <span class="top-card-emoji" aria-hidden="true">🏆</span>
        <div class="top-card-info">
          <p>El que más ha pagado</p>
          <strong>${escapeHtml(topP.name)} — ${formatAmount(topAmt, trip.currency)}</strong>
        </div>
      `;
    }
  }

  // Chart
  const canvas = document.getElementById('person-chart');
  if (!canvas) return;

  const labels = trip.participants.map(p => p.name);
  const data = trip.participants.map(p => Math.round((spending[p.id] || 0) * 100) / 100);
  const colors = trip.participants.map(p => p.color);
  const bgColors = trip.participants.map(p => p.color + '33');

  if (state.chart) { state.chart.destroy(); state.chart = null; }

  state.chart = new Chart(canvas, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Gastado',
        data,
        backgroundColor: bgColors,
        borderColor: colors,
        borderWidth: 2,
        borderRadius: 8,
        borderSkipped: false,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: { label: ctx => ` ${formatAmount(ctx.raw, trip.currency)}` },
          backgroundColor: '#1E1E35',
          titleColor: '#E2E8F0',
          bodyColor: '#94A3B8',
          borderColor: 'rgba(139,92,246,0.3)',
          borderWidth: 1,
          padding: 12,
          cornerRadius: 8,
        }
      },
      scales: {
        y: {
          grid: { color: 'rgba(255,255,255,0.05)' },
          ticks: { color: '#64748B', callback: v => formatAmount(v, trip.currency) },
          beginAtZero: true,
        },
        x: {
          grid: { display: false },
          ticks: { color: '#94A3B8', font: { weight: '600' } }
        }
      }
    }
  });
}

// =====================================================
// ESCAPE HTML
// =====================================================
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = String(str || '');
  return div.innerHTML;
}

// =====================================================
// TRIP CRUD
// =====================================================
function createTrip(name, currency) {
  const EMOJIS = ['✈️', '🏖️', '🏔️', '🎉', '🍽️', '🚗', '🏠', '🎭', '🌍', '🛳️'];
  return {
    id: uid(),
    name: name.trim(),
    currency: currency || 'EUR',
    emoji: EMOJIS[Math.floor(Math.random() * EMOJIS.length)],
    createdAt: Date.now(),
    participants: [],
    expenses: [],
  };
}

function deleteTrip(tripId) {
  const index = state.trips.findIndex(t => t.id === tripId);
  if (index === -1) return false;

  state.trips.splice(index, 1);
  const saved = saveState();

  // Si por alguna razón se elimina el viaje actualmente abierto, salimos
  // también de su pantalla para evitar un estado visual inconsistente.
  if (state.currentTripId === tripId) {
    state.currentTripId = null;
    if (state.chart) {
      try { state.chart.destroy(); } catch (e) { /* noop */ }
      state.chart = null;
    }
    document.getElementById('trip-screen')?.classList.remove('active');
    document.getElementById('home-screen')?.classList.add('active');
  }

  renderHome();
  showToast(saved ? '🗑️ Viaje eliminado' : '🗑️ Viaje eliminado de esta sesión');
  return true;
}

// =====================================================
// PARTICIPANT CRUD
// =====================================================
function addParticipant(name, color) {
  const trip = getCurrentTrip();
  if (!trip) return;
  trip.participants.push({ id: uid(), name: name.trim(), color });
  saveState();
  renderParticipants(trip);
  updateTripMeta(trip);
}

function removeParticipant(participantId) {
  const trip = getCurrentTrip();
  if (!trip) return false;

  const hasExpenses = trip.expenses.some(
    e => e.paidBy === participantId || (e.splitAmong && e.splitAmong.includes(participantId))
  );
  if (hasExpenses) {
    showToast('⚠️ Elimina primero los gastos donde participa esta persona');
    return false;
  }

  const p = getParticipant(trip, participantId);
  if (!p) return false;

  trip.participants = trip.participants.filter(person => person.id !== participantId);
  const saved = saveState();
  renderParticipants(trip);
  updateTripMeta(trip);
  if (state.activeTab === 'summary') renderSummary(trip);
  if (state.activeTab === 'stats') renderStats(trip);
  showToast(saved ? `✅ ${p.name} eliminado` : `⚠️ ${p.name} eliminado de esta sesión`);
  return true;
}

// =====================================================
// EXPENSE CRUD
// =====================================================
function addExpense(description, amount, paidBy, splitAmong, category) {
  const trip = getCurrentTrip();
  if (!trip) return;
  trip.expenses.push({
    id: uid(),
    description: description.trim(),
    amount: parseFloat(amount),
    paidBy,
    splitAmong,
    category: category || 'other',
    date: Date.now(),
  });
  saveState();
  renderExpenses(trip);
  updateTripMeta(trip);
}

function deleteExpense(expenseId) {
  const trip = getCurrentTrip();
  if (!trip) return false;

  const index = trip.expenses.findIndex(e => e.id === expenseId);
  if (index === -1) return false;

  trip.expenses.splice(index, 1);
  const saved = saveState();
  renderExpenses(trip);
  updateTripMeta(trip);

  // El gasto afecta al resumen y a las estadísticas, así que las refrescamos
  // inmediatamente si el usuario está en esas pestañas.
  if (state.activeTab === 'summary') renderSummary(trip);
  if (state.activeTab === 'stats') renderStats(trip);

  showToast(saved ? '🗑️ Gasto eliminado' : '⚠️ Gasto eliminado de esta sesión');
  return true;
}

// =====================================================
// UI HELPERS
// =====================================================
function renderColorPicker() {
  const picker = document.getElementById('color-picker');
  if (!picker) return;
  picker.innerHTML = '';
  PARTICIPANT_COLORS.forEach(color => {
    const btn = document.createElement('div');
    btn.className = 'color-option' + (color === state.selectedColor ? ' selected' : '');
    btn.style.background = color;
    btn.dataset.color = color;
    btn.title = color;
    btn.setAttribute('role', 'radio');
    btn.setAttribute('aria-checked', color === state.selectedColor ? 'true' : 'false');
    btn.setAttribute('tabindex', '0');
    const select = () => {
      state.selectedColor = color;
      picker.querySelectorAll('.color-option').forEach(o => {
        o.classList.remove('selected');
        o.setAttribute('aria-checked', 'false');
      });
      btn.classList.add('selected');
      btn.setAttribute('aria-checked', 'true');
    };
    btn.addEventListener('click', select);
    btn.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') select(); });
    picker.appendChild(btn);
  });
}

function renderCategoryGrid() {
  const grid = document.getElementById('category-grid');
  if (!grid) return;
  grid.innerHTML = '';
  CATEGORIES.forEach(cat => {
    const btn = document.createElement('button');
    btn.className = 'category-btn' + (cat.id === state.selectedCategory ? ' selected' : '');
    btn.type = 'button';
    btn.dataset.category = cat.id;
    btn.setAttribute('role', 'radio');
    btn.setAttribute('aria-checked', cat.id === state.selectedCategory ? 'true' : 'false');
    btn.innerHTML = `<span aria-hidden="true">${cat.emoji}</span><span>${cat.label}</span>`;
    btn.addEventListener('click', () => {
      state.selectedCategory = cat.id;
      grid.querySelectorAll('.category-btn').forEach(b => {
        b.classList.remove('selected');
        b.setAttribute('aria-checked', 'false');
      });
      btn.classList.add('selected');
      btn.setAttribute('aria-checked', 'true');
    });
    grid.appendChild(btn);
  });
}

function populateExpenseModal() {
  const trip = getCurrentTrip();
  if (!trip) return;

  // Paid by select
  const select = document.getElementById('expense-paidby-input');
  if (select) {
    select.innerHTML = '';
    trip.participants.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p.id;
      opt.textContent = p.name;
      select.appendChild(opt);
    });
  }

  // Split custom list
  const customList = document.getElementById('split-custom-list');
  if (customList) {
    customList.innerHTML = '';
    trip.participants.forEach(p => {
      const div = document.createElement('div');
      div.className = 'split-person-option checked';
      div.innerHTML = `
        <input type="checkbox" id="split-check-${p.id}" value="${p.id}" checked aria-label="${escapeHtml(p.name)}">
        <div class="avatar" style="background:${p.color};width:28px;height:28px;font-size:10px" aria-hidden="true">${getInitials(p.name)}</div>
        <label for="split-check-${p.id}" class="split-person-name">${escapeHtml(p.name)}</label>
      `;
      const cb = div.querySelector('input');
      cb.addEventListener('change', e => div.classList.toggle('checked', e.target.checked));
      div.addEventListener('click', e => {
        if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'LABEL') {
          cb.checked = !cb.checked;
          div.classList.toggle('checked', cb.checked);
        }
      });
      customList.appendChild(div);
    });
  }

  renderCategoryGrid();
}

function initTabIndicator() {
  const activeBtn = document.querySelector('.tab-btn.active');
  const indicator = document.getElementById('tab-indicator');
  if (activeBtn && indicator) {
    const bar = document.querySelector('.tab-bar');
    if (!bar) return;
    const barRect = bar.getBoundingClientRect();
    const btnRect = activeBtn.getBoundingClientRect();
    indicator.style.left = `${btnRect.left - barRect.left}px`;
    indicator.style.width = `${btnRect.width}px`;
  }
}

// =====================================================
// COOKIE CONSENT
// =====================================================
function initCookieBanner() {
  const banner = document.getElementById('cookie-banner');
  if (!banner) return;
  let accepted = false;
  try {
    accepted = localStorage.getItem(COOKIES_ACCEPTED_KEY) === '1';
  } catch (e) { /* private mode */ }

  if (!accepted) {
    setTimeout(() => banner.classList.add('show'), 800);
  }
}

function acceptCookies() {
  const banner = document.getElementById('cookie-banner');
  if (banner) banner.classList.remove('show');
  try {
    localStorage.setItem(COOKIES_ACCEPTED_KEY, '1');
  } catch (e) { /* private mode */ }
}

// =====================================================
// FAQ ACCORDION
// =====================================================
function initFaqAccordion() {
  document.querySelectorAll('.faq-question').forEach(btn => {
    btn.addEventListener('click', () => {
      const isOpen = btn.getAttribute('aria-expanded') === 'true';
      const answer = btn.nextElementSibling;
      if (!answer) return;

      // Close all
      document.querySelectorAll('.faq-question').forEach(other => {
        other.setAttribute('aria-expanded', 'false');
        const otherAnswer = other.nextElementSibling;
        if (otherAnswer) otherAnswer.hidden = true;
      });

      // Toggle clicked
      if (!isOpen) {
        btn.setAttribute('aria-expanded', 'true');
        answer.hidden = false;
      }
    });
  });
}

// =====================================================
// INPUT VALIDATION HELPERS
// =====================================================
function validateTripName(name) {
  if (!name || name.trim().length === 0) return 'Escribe un nombre para el viaje';
  if (name.trim().length > 50) return 'El nombre es demasiado largo (máx. 50 caracteres)';
  return null;
}

function validateParticipantName(name, trip) {
  if (!name || name.trim().length === 0) return 'Escribe un nombre';
  if (name.trim().length > 25) return 'El nombre es demasiado largo (máx. 25 caracteres)';
  if (trip && trip.participants.some(p => p.name.toLowerCase() === name.trim().toLowerCase())) {
    return 'Ya hay alguien con ese nombre en este viaje';
  }
  return null;
}

function validateExpense(description, amount) {
  if (!description || description.trim().length === 0) return 'Escribe una descripción del gasto';
  const num = parseFloat(amount);
  if (isNaN(num) || num <= 0) return 'El importe debe ser mayor que 0';
  if (num > 9999999) return 'El importe parece demasiado alto';
  return null;
}

// =====================================================
// EVENT LISTENERS
// =====================================================
function setupEventListeners() {

  // ---- Cookie consent ----
  const acceptBtn = document.getElementById('btn-accept-cookies');
  if (acceptBtn) acceptBtn.addEventListener('click', acceptCookies);

  const cookiePolicyLink = document.getElementById('btn-cookie-policy');
  if (cookiePolicyLink) cookiePolicyLink.addEventListener('click', () => openModal('modal-cookies'));

  // ---- Home: Create trip ----
  const createBtn = document.getElementById('btn-create-trip');
  if (createBtn) createBtn.addEventListener('click', () => {
    const nameInput = document.getElementById('trip-name-input');
    const currInput = document.getElementById('trip-currency-input');
    if (nameInput) nameInput.value = '';
    if (currInput) currInput.value = 'EUR';
    openModal('modal-trip');
  });

  // ---- Home: Clear all data ----
  const clearBtn = document.getElementById('btn-clear-all-data');
  if (clearBtn) clearBtn.addEventListener('click', clearAllData);

  // ---- Modal: Confirm trip ----
  const confirmTrip = document.getElementById('btn-confirm-trip');
  if (confirmTrip) confirmTrip.addEventListener('click', () => {
    const name = document.getElementById('trip-name-input')?.value || '';
    const err = validateTripName(name);
    if (err) { showToast(`✏️ ${err}`); document.getElementById('trip-name-input')?.focus(); return; }
    const currency = document.getElementById('trip-currency-input')?.value || 'EUR';
    const trip = createTrip(name, currency);
    state.trips.unshift(trip);
    saveState();
    closeModal('modal-trip');
    renderHome();
    openTrip(trip.id);
    showToast('🎉 ¡Viaje creado!');
  });

  // ---- Dynamic actions: one document-level delegation ----
  // Los listados de viajes, participantes y gastos se regeneran con innerHTML.
  // Delegar en document evita que los botones pierdan sus eventos al renderizar.
  document.addEventListener('click', e => {
    const openBtn = e.target.closest('.trip-card-open');
    if (openBtn) {
      openTrip(openBtn.dataset.tripId);
      return;
    }

    const deleteTripBtn = e.target.closest('.trip-card-delete');
    if (deleteTripBtn) {
      e.preventDefault();
      e.stopPropagation();
      if (confirm('¿Eliminar este viaje? Esta acción no se puede deshacer.')) {
        deleteTrip(deleteTripBtn.dataset.tripId);
      }
      return;
    }

    const removeParticipantBtn = e.target.closest('.btn-remove');
    if (removeParticipantBtn) {
      e.preventDefault();
      e.stopPropagation();
      const trip = getCurrentTrip();
      const participant = trip ? getParticipant(trip, removeParticipantBtn.dataset.participantId) : null;
      if (participant && !trip.expenses.some(exp =>
        exp.paidBy === participant.id || (exp.splitAmong || []).includes(participant.id)
      )) {
        if (confirm(`¿Eliminar a ${participant.name}?`)) {
          removeParticipant(participant.id);
        }
      } else {
        removeParticipant(removeParticipantBtn.dataset.participantId);
      }
      return;
    }

    const deleteExpenseBtn = e.target.closest('.btn-delete-expense');
    if (deleteExpenseBtn) {
      e.preventDefault();
      e.stopPropagation();
      if (confirm('¿Eliminar este gasto? Esta acción no se puede deshacer.')) {
        deleteExpense(deleteExpenseBtn.dataset.expenseId);
      }
    }
  });

  // ---- Trip: Back ----
  const backBtn = document.getElementById('btn-back');
  if (backBtn) backBtn.addEventListener('click', () => {
    document.getElementById('trip-screen').classList.remove('active');
    document.getElementById('home-screen').classList.add('active');
    state.currentTripId = null;
    if (state.chart) { state.chart.destroy(); state.chart = null; }
    renderHome();
    history.replaceState(null, null, ' ');
  });

  // ---- Trip: Share ----
  const shareBtn = document.getElementById('btn-share-trip');
  if (shareBtn) shareBtn.addEventListener('click', () => {
    const trip = getCurrentTrip();
    if (!trip) return;
    const url = generateShareUrl(trip);
    const input = document.getElementById('share-url-input');
    if (input) input.value = url;
    openModal('modal-share');
  });

  // ---- Share: Copy link ----
  const copyLinkBtn = document.getElementById('btn-copy-share-link');
  if (copyLinkBtn) copyLinkBtn.addEventListener('click', () => {
    const input = document.getElementById('share-url-input');
    if (!input) return;
    navigator.clipboard.writeText(input.value).then(() => {
      showToast('🔗 Link copiado al portapapeles');
      closeModal('modal-share');
    }).catch(() => {
      input.select();
      document.execCommand('copy');
      showToast('🔗 Link copiado');
      closeModal('modal-share');
    });
  });

  // ---- Tabs ----
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });

  // ---- Participants: Add ----
  const addParticipantBtn = document.getElementById('btn-add-participant');
  if (addParticipantBtn) addParticipantBtn.addEventListener('click', () => {
    const trip = getCurrentTrip();
    if (!trip) return;
    const usedColors = trip.participants.map(p => p.color);
    state.selectedColor = PARTICIPANT_COLORS.find(c => !usedColors.includes(c)) || PARTICIPANT_COLORS[0];
    const nameInput = document.getElementById('participant-name-input');
    if (nameInput) nameInput.value = '';
    renderColorPicker();
    openModal('modal-participant');
  });

  // ---- Modal: Confirm participant ----
  const confirmParticipantBtn = document.getElementById('btn-confirm-participant');
  if (confirmParticipantBtn) confirmParticipantBtn.addEventListener('click', () => {
    const name = document.getElementById('participant-name-input')?.value || '';
    const trip = getCurrentTrip();
    const err = validateParticipantName(name, trip);
    if (err) { showToast(`✏️ ${err}`); document.getElementById('participant-name-input')?.focus(); return; }
    addParticipant(name, state.selectedColor);
    closeModal('modal-participant');
    showToast(`✅ ${name.trim()} añadido al viaje`);
  });

  // ---- Expenses: Add ----
  const addExpenseBtn = document.getElementById('btn-add-expense');
  if (addExpenseBtn) addExpenseBtn.addEventListener('click', () => {
    const trip = getCurrentTrip();
    if (!trip) return;
    if (trip.participants.length < 1) {
      showToast('⚠️ Añade al menos una persona primero');
      return;
    }
    state.selectedCategory = 'other';
    state.splitMode = 'all';
    const descInput = document.getElementById('expense-desc-input');
    const amtInput = document.getElementById('expense-amount-input');
    const splitCustomList = document.getElementById('split-custom-list');
    const splitAllBtn = document.getElementById('split-all-btn');
    const splitCustomBtn = document.getElementById('split-custom-btn');
    if (descInput) descInput.value = '';
    if (amtInput) amtInput.value = '';
    if (splitCustomList) splitCustomList.style.display = 'none';
    if (splitAllBtn) { splitAllBtn.classList.add('active'); splitAllBtn.setAttribute('aria-pressed', 'true'); }
    if (splitCustomBtn) { splitCustomBtn.classList.remove('active'); splitCustomBtn.setAttribute('aria-pressed', 'false'); }
    populateExpenseModal();
    openModal('modal-expense');
  });

  // ---- Split toggle ----
  const splitAllBtn = document.getElementById('split-all-btn');
  const splitCustomBtn = document.getElementById('split-custom-btn');
  const splitCustomList = document.getElementById('split-custom-list');

  if (splitAllBtn) splitAllBtn.addEventListener('click', () => {
    state.splitMode = 'all';
    splitAllBtn.classList.add('active'); splitAllBtn.setAttribute('aria-pressed', 'true');
    if (splitCustomBtn) { splitCustomBtn.classList.remove('active'); splitCustomBtn.setAttribute('aria-pressed', 'false'); }
    if (splitCustomList) splitCustomList.style.display = 'none';
  });

  if (splitCustomBtn) splitCustomBtn.addEventListener('click', () => {
    state.splitMode = 'custom';
    splitCustomBtn.classList.add('active'); splitCustomBtn.setAttribute('aria-pressed', 'true');
    if (splitAllBtn) { splitAllBtn.classList.remove('active'); splitAllBtn.setAttribute('aria-pressed', 'false'); }
    if (splitCustomList) splitCustomList.style.display = '';
  });

  // ---- Modal: Confirm expense ----
  const confirmExpenseBtn = document.getElementById('btn-confirm-expense');
  if (confirmExpenseBtn) confirmExpenseBtn.addEventListener('click', () => {
    const trip = getCurrentTrip();
    if (!trip) return;

    const description = document.getElementById('expense-desc-input')?.value || '';
    const amountRaw = document.getElementById('expense-amount-input')?.value || '';
    const paidBy = document.getElementById('expense-paidby-input')?.value;

    const err = validateExpense(description, amountRaw);
    if (err) {
      showToast(`✏️ ${err}`);
      const targetId = err.includes('descripción') ? 'expense-desc-input' : 'expense-amount-input';
      document.getElementById(targetId)?.focus();
      return;
    }

    let splitAmong;
    if (state.splitMode === 'all') {
      splitAmong = trip.participants.map(p => p.id);
    } else {
      splitAmong = Array.from(
        document.querySelectorAll('#split-custom-list input[type="checkbox"]:checked')
      ).map(cb => cb.value);
      if (splitAmong.length === 0) {
        showToast('⚠️ Selecciona al menos una persona entre quienes dividir');
        return;
      }
    }

    addExpense(description, parseFloat(amountRaw), paidBy, splitAmong, state.selectedCategory);
    closeModal('modal-expense');
    showToast(`✅ Gasto registrado: ${description.trim()}`);
  });

  // ---- Summary: WhatsApp ----
  const waAllBtn = document.getElementById('btn-whatsapp-all');
  if (waAllBtn) waAllBtn.addEventListener('click', () => {
    const trip = getCurrentTrip();
    if (!trip) return;
    const msg = generateWhatsAppMessage(trip);
    navigator.clipboard.writeText(msg).then(() => {
      showToast('💬 Mensaje copiado — pégalo en WhatsApp');
    }).catch(() => {
      window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank');
    });
  });

  // ---- Summary: Export image ----
  const exportBtn = document.getElementById('btn-export-image');
  if (exportBtn) exportBtn.addEventListener('click', exportAsImage);

  // ---- Legal modals ----
  const privacyBtn = document.getElementById('btn-privacy-policy');
  if (privacyBtn) privacyBtn.addEventListener('click', () => openModal('modal-privacy'));

  const termsBtn = document.getElementById('btn-terms');
  if (termsBtn) termsBtn.addEventListener('click', () => openModal('modal-terms'));

  const cookiesBtn = document.getElementById('btn-cookies-policy');
  if (cookiesBtn) cookiesBtn.addEventListener('click', () => openModal('modal-cookies'));

  // ---- Modal: Close buttons (delegation) ----
  document.querySelectorAll('.modal-close, [data-modal]').forEach(el => {
    el.addEventListener('click', () => {
      const modalId = el.dataset.modal;
      if (modalId) closeModal(modalId);
    });
  });

  // ---- Modal: Click outside ----
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', e => {
      if (e.target === overlay) closeModal(overlay.id);
    });
  });

  // ---- Escape key closes modals ----
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      const open = document.querySelector('.modal-overlay.open');
      if (open) closeModal(open.id);
    }
  });

  // ---- Enter key shortcuts ----
  document.getElementById('trip-name-input')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') document.getElementById('btn-confirm-trip')?.click();
  });
  document.getElementById('participant-name-input')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') document.getElementById('btn-confirm-participant')?.click();
  });
  document.getElementById('expense-amount-input')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') document.getElementById('btn-confirm-expense')?.click();
  });

  // ---- Prevent negative amounts ----
  document.getElementById('expense-amount-input')?.addEventListener('input', e => {
    if (parseFloat(e.target.value) < 0) e.target.value = '';
  });
}

// =====================================================
// INIT
// =====================================================
function init() {
  loadState();
  initCookieBanner();
  initFaqAccordion();

  // Check for shared trip in URL hash
  const sharedTrip = loadTripFromUrl();
  if (sharedTrip && sharedTrip.id && sharedTrip.name) {
    const existing = state.trips.find(t => t.id === sharedTrip.id);
    if (!existing) {
      // Sanitize imported trip
      if (!Array.isArray(sharedTrip.participants)) sharedTrip.participants = [];
      if (!Array.isArray(sharedTrip.expenses)) sharedTrip.expenses = [];
      state.trips.unshift(sharedTrip);
      saveState();
      showToast('🔗 Viaje importado desde link compartido');
    }
    renderHome();
    openTrip(sharedTrip.id);
  } else {
    renderHome();
  }

  setupEventListeners();
  requestAnimationFrame(initTabIndicator);
}

document.addEventListener('DOMContentLoaded', init);
