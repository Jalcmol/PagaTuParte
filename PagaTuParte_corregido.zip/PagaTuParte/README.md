PagaTuParte — Dividir Gastos entre Amigos
Web app gratuita para dividir gastos de viajes, cenas y eventos. Monetizada con Google AdSense. Sin registro, sin cuenta, todo en el navegador.

Propuesta de Valor
La competencia (Splitwise, Tricount) requiere cuenta y son apps nativas. Esta web funciona sin registro, es instantánea y tiene extras únicos que la diferencian.

Funcionalidades a Construir
🧮 Core
Crear un viaje/evento con nombre y moneda
Añadir participantes con avatar de color único
Registrar gastos: descripción, importe, quién pagó, entre quiénes se divide
División igual o personalizada (cada uno paga X%)
Algoritmo de simplificación de deudas (minimiza el número de transferencias)
Ver balances netos de cada persona
✨ Extras Diferenciadores
Mensaje de WhatsApp automático — genera el texto listo para copiar/enviar por WhatsApp con lo que debe cada persona
Link compartible — codifica el estado del viaje en la URL para compartir sin servidor
Selector de moneda — EUR, USD, MXN, COP, ARS, etc.
Gráfico de quién gasta más — chart visual por persona
Exportar resumen como imagen — tarjeta visual para el grupo de WhatsApp
Historial en LocalStorage — guarda los últimos viajes en el navegador
Stack Técnico (100% Gratis)
Capa	Tecnología
Estructura	HTML5 semántico
Estilos	CSS3 vanilla (glassmorphism, dark mode)
Lógica	JavaScript vanilla (ES6+)
Gráficos	Chart.js (CDN gratuito)
Export imagen	html2canvas (CDN gratuito)
Hosting	Netlify (gratis) / GitHub Pages / Vercel (gratis)
Anuncios	Google AdSense
Estructura de Archivos

/
├── index.html       # App completa
├── style.css        # Diseño premium dark mode
└── app.js           # Toda la lógica
Diseño Visual
Tema: Dark mode premium con gradientes violeta/índigo
Estilo: Glassmorphism + micro-animaciones
Tipografía: Inter (Google Fonts)
Mobile-first: Pensado para móvil (se usa en tiempo real en viajes)
Secciones de la UI:
Hero/Landing — CTA "Crear nuevo viaje" + lista de viajes guardados
Vista de Viaje con 4 tabs:
👥 Participantes — añadir/eliminar amigos
💸 Gastos — lista de gastos, añadir nuevo
⚖️ Resumen — quién debe a quién, botón WhatsApp
📊 Estadísticas — gráfico de gastos por persona
Modelo de Datos
javascript

trip = {
  id: "uuid",
  name: "Viaje a Roma",
  currency: "EUR",
  createdAt: timestamp,
  participants: [
    { id: "p1", name: "Carlos", color: "#8B5CF6" }
  ],
  expenses: [
    {
      id: "e1",
      description: "Hotel",
      amount: 300,
      paidBy: "p1",
      splitAmong: ["p1", "p2", "p3"],
      date: timestamp
    }
  ]
}
Algoritmo de Deudas
Calcular balance neto de cada persona (pagó - le corresponde)
Separar en acreedores (balance positivo) y deudores (balance negativo)
Aplicar algoritmo greedy para minimizar transferencias
Output: lista de "X debe Y€ a Z"
Monetización con Ads
Banner superior (leaderboard 728x90)
Banner entre secciones (rectangle 300x250)
Integración con Google AdSense al publicar
Verificación
Probar cálculo de deudas con casos reales
Verificar link compartible (codificación/decodificación de URL)
Comprobar exportación de imagen
Verificar generación de mensaje WhatsApp
Responsive en móvil